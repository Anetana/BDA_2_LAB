﻿using BDA_WBA_Laboratory_2.Connection_Details;
using BDA_WBA_Laboratory_2.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDA_WBA_Laboratory_2.Repository
{
    internal class StudentRepository
    {

        public static List<StudentInfo> GetStudents() { 

            var students = new List<StudentInfo>();
            const string query = @"WBA.GetStudents";

            using (var command = new SqlCommand(query)) {
                try
                {
                    command.Connection = new SqlConnection(WBADatabaseConnection.GetConnectionString());
                    command.Connection.Open();
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            students.Add(new StudentInfo
                            {
                                Id = Convert.ToInt32(reader["StudentId"]),
                                Name = reader["StudentName"].ToString()
                            });

                        }

                    }


                }
                catch (Exception ex)
                {
                    throw new Exception($"From Student Repository GetStudents: {ex.Message}");
                }

                finally {
                    command.Connection.Close();
                }
            
            
            }

            return students;

        
        }

        
    

      
    
    }
}
