﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDA_WBA_Laboratory_2.Connection_Details
{
    internal class WBADatabaseConnection
    {
        private static SqlConnectionStringBuilder connectionString;

        public static string GetConnectionString() { 
        if (connectionString == null)
            {
                FillConnectionString();
            }
            return connectionString.ToString();
        }

        private static void FillConnectionString()
        {
            connectionString = new SqlConnectionStringBuilder
            {
                UserID = "",
                Password = "",
                DataSource = "",
                InitialCatalog = "WBA_DatabaseConcepts"
            };
        }
    }
}
