﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BDA_WBA_Laboratory_2.Models
{
    internal class StudentInfo
    {

        public int Id { get; set; }
        public string Name { get; set; }


        public string toString()
        {
            string result = "ID: " + Id + "\nName: " + Name;
            return result;
        }
    }
}
