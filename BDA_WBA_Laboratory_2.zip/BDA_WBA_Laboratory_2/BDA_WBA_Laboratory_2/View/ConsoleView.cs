﻿using BDA_WBA_Laboratory_2.Models;
using BDA_WBA_Laboratory_2.Repository;
using BDA_WBA_Laboratory_2.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDA_WBA_Laboratory_2.View
{
    internal class ConsoleView
    {
        public static void Main(string[] args) {

            var students = StudentRepository.GetStudents();


            for (int i = 0; i <  students.Count; i++) {
                MessageBox.Show(students[i].toString());
            }
        }
    }
}
