﻿using BDA_WBA_Laboratory_2.Models;
using BDA_WBA_Laboratory_2.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDA_WBA_Laboratory_2.Server
{
    internal class StudentServer
    {

        public static List<StudentInfo> GetStudents() {
            return StudentRepository.GetStudents();
        }
    }
}
